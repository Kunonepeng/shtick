# 图像编码Notebook课堂副本

保留assets/与demos/的相对位置，从解压目录启动python -m jupyter lab .，选择已安装依赖的Python内核。

先运行准备单元；每题先写预测或算式，再逐单元运行。不要Run All。E1先交答，收齐后才开启反馈。

本包不含PPTX。对应1-2-3-image-encoding-panda-v4-20261011.pptx（85页），页码见Notebook标题。

依赖为requirements-notebook.txt，课前安装；课堂无需网络。原素材由用户提供，公开再分发许可未确认。
